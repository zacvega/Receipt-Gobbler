//
//  Receipt_GobblerApp.swift
//  Receipt Gobbler
//
//  Created by jinshi bai on 9/3/24.
//

import SwiftUI

@main
struct Receipt_GobblerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
